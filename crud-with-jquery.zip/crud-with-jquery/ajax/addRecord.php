<?php
	if(isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && isset( $_FILES["file"] ) && !empty( $_FILES["file"]["name"] ))
	{

		// include Database connection file 
		include("db_connection.php");

		// get values 
		$first_name = $_POST['first_name'];
		$last_name = $_POST['last_name'];
		$email = $_POST['email'];

  	// Get image name
  	//$image = $_FILES['file']['name'];
  	
  	// image file directory
  	//$target = "files/".basename($image);

		 $name = $_FILES['file']['name'];
		 $target_dir = "files/";
		 $target_file = $target_dir . basename($_FILES["file"]["name"]);

		 // Select file type
		 $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

		 // Valid file extensions
		 $extensions_arr = array("jpg","jpeg","png","gif");

		 // Check extension
		 if( in_array($imageFileType,$extensions_arr) ){
		 
		  // Convert to base64 
		  $image_base64 = base64_encode(file_get_contents($_FILES['file']['tmp_name']) );
		  $image = 'data:image/'.$imageFileType.';base64,'.$image_base64;
		  // Insert record

  	

		$query = "INSERT INTO users(first_name, last_name, email, file) VALUES('$first_name', '$last_name', '$email', '$image')";
				
		if (!$result = mysqli_query($con, $query)) {
		
	        exit(mysqli_error($con));

	    }
	    //move_uploaded_file($_FILES['file']['tmp_name'], 'files/' . $_FILES['file']['name']);
	    move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
	    echo "1 Record Added!";
	}
?>