<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>iTech Empires Demo - PHP File upload using jQuery</title>

<!-- Bootstrap CSS File -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
</head>
<body>

<!-- Content Section -->
<div class="container">
<div class="row">
<div class="col-md-12">
<h2>PHP File Upload using jQuery</h2>
</div>
</div>
<div class="row">
<div class="col-md-6 col-md-offset-0">
<div class="form-group">
<form enctype="multipart/form-data">
<label>Select File to Upload</label>
<input id="file_to_upload" type="file" class="form-control" />
</form>
</div>
<div class="form-group">
<button onclick="uploadFile()" class="btn btn-primary">Submit</button>
</div>
</div>
</div>
</div>
<!-- /Content Section -->

<!-- Jquery JS file -->
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>

<!-- Bootstrap JS file -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<!-- Custom JS file -->
<script type="text/javascript" src="js/Uploadscript.js"></script>
</body>
</html>